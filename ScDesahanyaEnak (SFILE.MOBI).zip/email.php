<?php
$sender = 'From: Yosoka - Hosting🇮🇩 || <stokpes782@gmail.com>';

$email = 'gallztod@gmail.com';
 // GANTI EMAIL KAMU DISINI
?>