<?php

$linkweb = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
$link = 'https://facebook.com'; //GANTI APA SAJA
$namafile = 'GANTI NAMA FILE'; //JANGAN DIJUAL AJG
$ukuranfile = '1000.3MB'; //KB MB GB TB GANTI UKURAN FILE

$sender = 'From: RESS MEDIAFIRE GG <ahmadgans@xx.com>';
$emailku = 'stokm638@gmail.com'; //GANTI EMAILMU DI SINI



?>