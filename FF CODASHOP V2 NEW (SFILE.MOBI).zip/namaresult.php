<?php
$sender ='From: Samlekom Mamank🇮🇩 <admin@alexhost.my.id>';
?>