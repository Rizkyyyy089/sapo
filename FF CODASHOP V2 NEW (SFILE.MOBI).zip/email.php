<?php

$alexhost = 'emailmu@gmail.com'; // EMAIL KAMU

$download = 'sender.com';

?>